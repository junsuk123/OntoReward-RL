# Processed UrbanNav-HK Data Contract

Required columns per synchronized epoch:

- `numSV`
- `hDOP`
- `vDOP`
- `hAcc`
- `vAcc`
- `gSpeed`
- `CNO_mean`
- `CNO_std`
- `CNO_gap`
- `low_elev_ratio`
- `PR_RMS`
- `Fault_SVID_count`
- `hard_label` (0/1), or `pos_error_2d` from which `>=3 m` is generated
- `soft_fault_prob` in `[0,1]`

Recommended provenance columns:

- `timestamp`
- `pos_error_2d`
- `residual`
- `scenario`
- receiver/source identifiers

Strict mode refuses to create a replacement `soft_fault_prob` because the prior presentation does not provide the exact residual-to-probability mapping.
