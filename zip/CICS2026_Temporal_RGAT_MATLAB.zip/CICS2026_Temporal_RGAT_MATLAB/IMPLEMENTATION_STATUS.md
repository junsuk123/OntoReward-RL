# 구현 상태 및 연구 결과 사용 조건

## 구현 완료
- 선행연구 Transformer, TransEDL-Hard, TransEDL-Soft, residual soft-label, Transformer-Dual EDL 비교
- Ontology R-GAT, R-GAT + Transformer, 제안 Temporal R-GAT + Dual EDL
- Temporal R-GAT: node/relation/time-lag attention, causal lag, multi-head gating, layer gating
- Ablation: time encoding 제거, relation type 제거, 1-head, 1-layer
- 현재 고장 검출(k=0) 및 미래 고장 예측(k=1,5,10)
- Precision/Recall/F1/Accuracy/Specificity/AUROC/AUPRC/Brier/NLL/ECE
- paired bootstrap F1 차이, exact McNemar test
- EDL uncertainty 및 attention(node/relation/lag/head/layer) export
- 결과 CSV/JSON/MAT/PNG 및 MATLAB figure 출력
- 합성 demo 데이터와 strict real-data loader/importer

## 이 환경에서 확인한 것
- 패키지 파일/데이터 계약/함수명/데모 CSV 정적 점검 완료
- 데모 CSV는 12개 필수 feature, hard label, soft probability를 포함
- hard label은 demo에서 pos_error_2d >= 3 m 규칙과 일치

## 이 환경에서 확인할 수 없는 것
이 ChatGPT 실행 환경에는 MATLAB/Octave가 없어 .m 파일을 실제 실행하지 못했습니다. `run_all_demo`가 환경 검사와 forward-shape 단위 테스트를 먼저 수행하도록 구성되어 있으므로 MATLAB R2025b에서 먼저 실행하십시오.

## 논문 수치 사용 조건
선행연구 발표자료에는 원 processed 12-feature matrices, residual-to-soft-label 정확한 매핑, 전체 training hyperparameter가 제공되지 않습니다. 따라서 동봉 demo 결과는 software smoke test일 뿐 연구 결과가 아닙니다. 실제 논문 비교에는 원 processed `medium.csv`, `harsh.csv`, `deep.csv` 또는 원 preprocessing/soft-label 코드를 사용해야 합니다. baseline Transformer-Dual EDL F1=0.950 ± 0.020 reproduction gate를 통과해야 proposed-vs-baseline 차이를 주 성능 결과로 해석하도록 설계했습니다.
