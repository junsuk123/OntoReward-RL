# CICS2026 Temporal R-GAT MATLAB Package

## 목적
선행연구의 **Transformer-Dual EDL** GNSS 고장검출 구조를 기준선으로 재현하고, 제안 구조인 **Ontology-constrained Temporal R-GAT + Dual EDL**을 동일 데이터/동일 분할에서 비교 검증하기 위한 MATLAB 패키지입니다.

핵심 비교:

1. Transformer (Supervised only)
2. Transformer-EDL (Hard label only)
3. Transformer-EDL (Soft label only)
4. Residual-based Soft Label (통계 모델 출력 자체)
5. Transformer-Dual EDL (선행연구 핵심 baseline)
6. R-GAT-Dual EDL (시간축 미확장 ablation)
7. R-GAT + Transformer + Dual EDL (중간 비교)
8. **Temporal R-GAT + Dual EDL (제안)**

추가로 미래 고장 예측 horizon `k=1,5,10`에서 Transformer-Dual EDL과 Temporal R-GAT-Dual EDL을 비교할 수 있습니다.

---

## 가장 먼저 실행

MATLAB R2025b + Deep Learning Toolbox 기준:

```matlab
cd <이 폴더>
check_environment
run_all_demo
```

`run_all_demo`는 먼저 데이터/EDL/Transformer/Temporal R-GAT forward-shape 단위 테스트를 수행한 뒤, 동봉된 합성 데이터로 학습-평가-통계-시각화-export 전체가 연결되는지 확인하는 **software smoke test**입니다. 이 결과를 논문 수치로 사용하면 안 됩니다.

실제 선행연구 비교는 다음 파일을 준비한 뒤 수행합니다.

```text
data/real/medium.csv
data/real/harsh.csv
data/real/deep.csv
```

그 후:

```matlab
run_all_real
```

---

## 실제 데이터 계약
각 CSV는 1 epoch = 1 row이며 다음 12개 feature가 필요합니다.

```text
numSV
hDOP
vDOP
hAcc
vAcc
gSpeed
CNO_mean
CNO_std
CNO_gap
low_elev_ratio
PR_RMS
Fault_SVID_count
```

그리고 다음 supervision이 필요합니다.

```text
hard_label          % 0 normal / 1 fault
soft_fault_prob     % [0,1]
```

`hard_label`이 없고 `pos_error_2d`가 있으면 `pos_error_2d >= 3 m`로 생성합니다.

**중요:** 선행연구 발표자료에는 원본 processed 12-feature matrix, residual→soft label 정확한 mapping, 전체 학습 hyperparameter가 공개되어 있지 않습니다. 따라서 strict mode는 `soft_fault_prob`이 없으면 실패하도록 설계했습니다. 임의의 soft label을 만들어 선행연구 재현으로 가장하지 않습니다.

---

## 데이터 분할
선행연구 발표 내용과 동일하게 기본 설정은:

```text
Train = Middle-Class Urban + Harsh Urban
Test  = Deep Urban
Window = 30
```

Hard fault label 기준은 GT 기반 GNSS 2-D 위치오차 `>= 3 m`입니다.

---

## 제안 모델

```text
12 Features × Window
        ↓
Ontology-Temporal Graph
        ↓
Temporal R-GAT
  - Node/Relation attention
  - Time-lag attention
  - Multi-head
  - Layer gating
        ↓
Dual EDL
  - Hard label head
  - Soft label head
        ↓
Dirichlet evidence fusion
        ↓
Fault probability + uncertainty
```

기존 R-GAT의 attention domain을 `node-relation`에서 `node-relation-time lag`로 확장합니다.

개념적으로:

```text
alpha_ijr  →  alpha_ijrΔ
```

여기서 `Δ=0...MaxLag`이며, 미래 정보가 현재 판단에 들어가지 않도록 항상 causal 조건만 사용합니다.

---

## 결과 파일
실행 후 `outputs/<run_name>/`에 생성됩니다.

- `metrics.csv`
- `paired_bootstrap_vs_prior.csv`
- `mcnemar_vs_prior.csv`
- `forecast_metrics.csv` (forecast 사용 시)
- `predictions_*.csv`
- `training_history_*.csv`
- `attention_node.csv`
- `attention_relation.csv`
- `attention_time_lag.csv`
- `attention_head.csv`
- `attention_layer.csv`
- `benchmark_summary.png`
- `fault_probability_timeseries.png`
- `attention_summary.png`
- `run_manifest.json`
- `models/*.mat`

모든 figure는 실행 시 MATLAB figure 창으로도 바로 표시됩니다.

---

## 재현 gate
선행연구 발표자료의 Proposed Dual EDL F1 = **0.950**을 기준으로 기본 허용오차 ±0.02를 사용합니다.

실제 processed data로 Transformer-Dual EDL baseline이 이 범위를 재현하지 못하면:

```text
baseline_reproduction_pass = false
```

로 기록되며, proposed-vs-baseline 차이를 논문 성능개선으로 해석하지 않도록 경고합니다.

---

## UrbanNav-HK 원자료
공식 데이터셋은 `IPNL-POLYU/UrbanNavDataset`입니다. Medium/Deep/Harsh 전체 ROS 데이터는 매우 크므로 이 패키지에 포함하지 않습니다. GNSS/GT 자료 다운로드는:

```matlab
open_urbannav_dataset
```

을 실행해 공식 페이지에서 받으세요.

선행연구의 정확한 processed table이 있다면 그것을 우선 사용해야 합니다. 원자료에서 새로 feature를 재구성하면 **동일 데이터셋을 사용하더라도 선행연구의 preprocessing 재현과는 별개**입니다.


---

## 구현 검증 상태
자세한 제한사항과 논문 수치 사용 조건은 `IMPLEMENTATION_STATUS.md`를 확인하세요.
