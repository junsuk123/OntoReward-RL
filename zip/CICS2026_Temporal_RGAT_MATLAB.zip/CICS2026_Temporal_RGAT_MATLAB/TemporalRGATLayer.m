classdef TemporalRGATLayer < nnet.layer.Layer & nnet.layer.Formattable
    %TEMPORALRGATLAYER Ontology-constrained relation-time graph attention.
    % Input: N x B x T (CBT), N=12 feature nodes.
    % Output: D x B x T (CBT), graph-pooled relational-temporal state.
    % Attention domain is expanded from (node,relation) to
    % (node,relation,time-lag). Only causal lags delta>=0 are used.

    properties
        Adjacency
        RelationNames
        NumNodes
        NumRelations
        HiddenSize
        NumHeads
        NumLayers
        MaxLag
        TimeDim
        UseTimeEncoding
    end
    properties (Learnable)
        InputScale       % D x N
        NodeEmbedding    % D x N
        WQ               % D x D x R x H x L
        WK
        WV
        RelationBias     % R x H x L
        TimeWeight       % P x H x L
        HeadGate         % D x H x L
        HeadBias         % H x L
        LayerGate        % D x L
        LayerBias        % L x 1
    end

    methods
        function layer=TemporalRGATLayer(hiddenSize,G,numHeads,numLayers,maxLag,timeDim,useTimeEncoding,name)
            layer.Name=name;
            layer.Description="Ontology-constrained Temporal Relational Graph Attention";
            layer.Adjacency=single(G.adjacency);
            layer.RelationNames=G.relations;
            layer.NumNodes=size(G.adjacency,1);
            layer.NumRelations=size(G.adjacency,3);
            layer.HiddenSize=hiddenSize;
            layer.NumHeads=numHeads;
            layer.NumLayers=numLayers;
            layer.MaxLag=maxLag;
            layer.TimeDim=timeDim;
            layer.UseTimeEncoding=logical(useTimeEncoding);
            D=hiddenSize; N=layer.NumNodes; R=layer.NumRelations; H=numHeads; L=numLayers;
            s=sqrt(2/(D+D));
            layer.InputScale=single(0.08*randn(D,N));
            layer.NodeEmbedding=single(0.02*randn(D,N));
            layer.WQ=single(s*randn(D,D,R,H,L));
            layer.WK=single(s*randn(D,D,R,H,L));
            layer.WV=single(s*randn(D,D,R,H,L));
            layer.RelationBias=single(zeros(R,H,L));
            layer.TimeWeight=single(0.02*randn(timeDim,H,L));
            layer.HeadGate=single(0.02*randn(D,H,L));
            layer.HeadBias=single(zeros(H,L));
            layer.LayerGate=single(0.02*randn(D,L));
            layer.LayerBias=single(zeros(L,1));
        end

        function Y=predict(layer,X), Y=doForward(layer,X); end
        function Y=forward(layer,X), Y=doForward(layer,X); end

        function S=analyze(layer,X)
            % X is numeric N x T for one window. Returns interpretable summaries.
            X=single(X);
            if size(X,1)~=layer.NumNodes, error('Expected %d nodes.',layer.NumNodes); end
            [~,~,S]=numericForward(layer,X);
        end
    end

    methods (Access=private)
        function Y=doForward(layer,X)
            fmt=dims(X); Xu=stripdims(X); sz=size(Xu);
            N=sz(1); B=sz(2); T=sz(3); D=layer.HiddenSize;
            if N~=layer.NumNodes, error('TemporalRGAT expected %d input features, got %d.',layer.NumNodes,N); end
            base=Xu(1,1,1)*0;
            Hseq=repmat(base,[D N B T]);
            for b=1:B
                for t=1:T
                    x=reshape(Xu(:,b,t),1,N);
                    Hseq(:,:,b,t)=layer.InputScale.*repmat(x,D,1)+layer.NodeEmbedding;
                end
            end
            outs=cell(layer.NumLayers,1);
            for l=1:layer.NumLayers
                Hnext=Hseq*0;
                for b=1:B
                    for t=1:T
                        current=Hseq(:,:,b,t);
                        Hheads=repmat(current(:,:,1)*0,[1 1 layer.NumHeads]);
                        hs=repmat(current(1,1)*0,[layer.NumHeads 1]);
                        for h=1:layer.NumHeads
                            maxLag=min(layer.MaxLag,t-1);
                            rowMax=repmat(current(1,1)*0-single(1e9),[N 1]);
                            scores=cell((maxLag+1)*layer.NumRelations,1);
                            vals=cell(size(scores)); masks=cell(size(scores)); q=0;
                            for dlt=0:maxLag
                                source=Hseq(:,:,b,t-dlt);
                                tb=timeBias(layer,dlt,h,l);
                                for r=1:layer.NumRelations
                                    q=q+1; M=layer.Adjacency(:,:,r);
                                    Q=layer.WQ(:,:,r,h,l)*current;
                                    K=layer.WK(:,:,r,h,l)*source;
                                    V=layer.WV(:,:,r,h,l)*source;
                                    Sc=(Q.'*K)/sqrt(D)+layer.RelationBias(r,h,l)+tb;
                                    Sc=Sc+(1-M)*single(-1e4);
                                    scores{q}=Sc; vals{q}=V; masks{q}=M;
                                    rowMax=max(rowMax,max(Sc,[],2));
                                end
                            end
                            denom=rowMax*0;
                            E=cell(q,1);
                            for k=1:q
                                E{k}=exp(scores{k}-rowMax).*masks{k};
                                denom=denom+sum(E{k},2);
                            end
                            msg=current*0;
                            for k=1:q
                                A=E{k}./(denom+single(1e-8));
                                msg=msg+vals{k}*A.';
                            end
                            hout=tanh(current+msg);
                            Hheads(:,:,h)=hout;
                            m=mean(hout,2);
                            hs(h)=sum(layer.HeadGate(:,h,l).*m)+layer.HeadBias(h,l);
                        end
                        gamma=softmax1d(hs);
                        comb=current*0;
                        for h=1:layer.NumHeads, comb=comb+gamma(h)*Hheads(:,:,h); end
                        Hnext(:,:,b,t)=comb;
                    end
                end
                Hseq=Hnext; outs{l}=Hseq;
            end
            Hfinal=Hseq*0;
            for b=1:B
                for t=1:T
                    ls=repmat(Hseq(1,1,b,t)*0,[layer.NumLayers 1]);
                    for l=1:layer.NumLayers
                        m=mean(outs{l}(:,:,b,t),2);
                        ls(l)=sum(layer.LayerGate(:,l).*m)+layer.LayerBias(l);
                    end
                    lam=softmax1d(ls); tmp=Hseq(:,:,b,t)*0;
                    for l=1:layer.NumLayers, tmp=tmp+lam(l)*outs{l}(:,:,b,t); end
                    Hfinal(:,:,b,t)=tmp;
                end
            end
            Z=repmat(base,[D B T]);
            for b=1:B, for t=1:T, Z(:,b,t)=mean(Hfinal(:,:,b,t),2); end, end
            Y=dlarray(Z,fmt);
        end

        function tb=timeBias(layer,dlt,h,l)
            if ~layer.UseTimeEncoding
                tb=layer.TimeWeight(1,h,l)*0;
            else
                phi=lagEncoding(layer,dlt);
                tb=sum(layer.TimeWeight(:,h,l).*phi);
            end
        end

        function phi=lagEncoding(layer,dlt)
            P=layer.TimeDim; phi=zeros(P,1,'single');
            scale=max(1,layer.MaxLag);
            x=single(dlt/scale);
            k=1;
            while k<=P
                f=single(2^floor((k-1)/2));
                phi(k)=sin(pi*f*x);
                if k+1<=P, phi(k+1)=cos(pi*f*x); end
                k=k+2;
            end
        end

        function [Z,Hfinal,S]=numericForward(layer,X)
            D=layer.HiddenSize; N=layer.NumNodes; T=size(X,2);
            Hseq=zeros(D,N,T,'single');
            for t=1:T
                Hseq(:,:,t)=extractNumeric(layer.InputScale).*repmat(reshape(X(:,t),1,N),D,1)+extractNumeric(layer.NodeEmbedding);
            end
            outs=cell(layer.NumLayers,1);
            nodeImp=zeros(N,1); relImp=zeros(layer.NumRelations,1); lagImp=zeros(layer.MaxLag+1,1);
            headAvg=zeros(layer.NumHeads,1);
            for l=1:layer.NumLayers
                Hnext=zeros(size(Hseq),'single');
                for t=1:T
                    current=Hseq(:,:,t); Hheads=zeros(D,N,layer.NumHeads,'single'); hs=zeros(layer.NumHeads,1,'single');
                    for h=1:layer.NumHeads
                        maxLag=min(layer.MaxLag,t-1); rowMax=-1e9*ones(N,1,'single');
                        entries={}; q=0;
                        for dlt=0:maxLag
                            source=Hseq(:,:,t-dlt); tb=extractNumeric(timeBias(layer,dlt,h,l));
                            for r=1:layer.NumRelations
                                q=q+1; M=layer.Adjacency(:,:,r);
                                Q=extractNumeric(layer.WQ(:,:,r,h,l))*current;
                                K=extractNumeric(layer.WK(:,:,r,h,l))*source;
                                V=extractNumeric(layer.WV(:,:,r,h,l))*source;
                                Sc=(Q.'*K)/sqrt(D)+extractNumeric(layer.RelationBias(r,h,l))+tb;
                                Sc=Sc+(1-M)*single(-1e4);
                                entries{q}=struct('S',Sc,'V',V,'M',M,'r',r,'lag',dlt); %#ok<AGROW>
                                rowMax=max(rowMax,max(Sc,[],2));
                            end
                        end
                        denom=zeros(N,1,'single');
                        for k=1:q
                            entries{k}.E=exp(entries{k}.S-rowMax).*entries{k}.M;
                            denom=denom+sum(entries{k}.E,2);
                        end
                        msg=zeros(D,N,'single');
                        for k=1:q
                            A=entries{k}.E./(denom+1e-8);
                            msg=msg+entries{k}.V*A.';
                            if t==T
                                nodeImp=nodeImp+sum(A,1).';
                                relImp(entries{k}.r)=relImp(entries{k}.r)+sum(A,'all');
                                lagImp(entries{k}.lag+1)=lagImp(entries{k}.lag+1)+sum(A,'all');
                            end
                        end
                        hout=tanh(current+msg); Hheads(:,:,h)=hout;
                        m=mean(hout,2); hs(h)=sum(extractNumeric(layer.HeadGate(:,h,l)).*m)+extractNumeric(layer.HeadBias(h,l));
                    end
                    gamma=softmax_numeric(hs); headAvg=headAvg+gamma/T/layer.NumLayers;
                    comb=zeros(D,N,'single'); for h=1:layer.NumHeads, comb=comb+gamma(h)*Hheads(:,:,h); end
                    Hnext(:,:,t)=comb;
                end
                Hseq=Hnext; outs{l}=Hseq;
            end
            Hfinal=zeros(size(Hseq),'single'); layerAvg=zeros(layer.NumLayers,1,'single');
            for t=1:T
                ls=zeros(layer.NumLayers,1,'single');
                for l=1:layer.NumLayers
                    m=mean(outs{l}(:,:,t),2);
                    ls(l)=sum(extractNumeric(layer.LayerGate(:,l)).*m)+extractNumeric(layer.LayerBias(l));
                end
                lam=softmax_numeric(ls); layerAvg=layerAvg+lam/T;
                tmp=zeros(D,N,'single'); for l=1:layer.NumLayers, tmp=tmp+lam(l)*outs{l}(:,:,t); end
                Hfinal(:,:,t)=tmp;
            end
            Z=squeeze(mean(Hfinal,2));
            S.node=nodeImp/(sum(nodeImp)+eps);
            S.relation=relImp/(sum(relImp)+eps);
            S.timeLag=lagImp/(sum(lagImp)+eps);
            S.head=headAvg/(sum(headAvg)+eps);
            S.layer=layerAvg/(sum(layerAvg)+eps);
        end
    end
end

function y=softmax1d(x)
x=x-max(x); e=exp(x); y=e/(sum(e)+single(1e-8));
end
function y=softmax_numeric(x)
x=x-max(x); e=exp(x); y=e/(sum(e)+eps('single'));
end
function x=extractNumeric(x)
if isa(x,'dlarray'), x=extractdata(x); end
if isa(x,'gpuArray'), x=gather(x); end
x=single(x);
end
