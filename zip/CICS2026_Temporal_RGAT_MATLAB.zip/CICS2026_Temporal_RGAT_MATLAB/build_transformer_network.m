function net = build_transformer_network(inputDim,outDim,cfg,prefixLayer)
%BUILD_TRANSFORMER_NETWORK Standard 2-layer Transformer encoder + global pooling.
% If prefixLayer is supplied, it is inserted after sequence input and before position encoding.
if nargin<4, prefixLayer=[]; end
D=cfg.transformer.dModel;
lg=layerGraph();
lg=addLayers(lg,sequenceInputLayer(inputDim,Normalization="none",Name="input"));
if isempty(prefixLayer)
    lg=addLayers(lg,fullyConnectedLayer(D,Name="embed"));
    lg=connectLayers(lg,"input","embed"); prev="embed";
else
    lg=addLayers(lg,prefixLayer);
    lg=connectLayers(lg,"input",prefixLayer.Name); prev=string(prefixLayer.Name);
    if isprop(prefixLayer,'HiddenSize') && prefixLayer.HiddenSize~=D
        lg=addLayers(lg,fullyConnectedLayer(D,Name="rgat_proj"));
        lg=connectLayers(lg,prev,"rgat_proj"); prev="rgat_proj";
    end
end
pos=SinusoidalPositionEncodingLayer(D,cfg.window,"pos");
lg=addLayers(lg,pos); lg=connectLayers(lg,prev,"pos"); prev="pos";
for l=1:cfg.transformer.numLayers
    [lg,prev]=add_encoder_block(lg,prev,l,cfg);
end
lg=addLayers(lg,globalAveragePooling1dLayer(Name="pool"));
lg=addLayers(lg,fullyConnectedLayer(outDim,Name="output"));
lg=connectLayers(lg,prev,"pool"); lg=connectLayers(lg,"pool","output");
net=dlnetwork(lg);
end

function [lg,outName]=add_encoder_block(lg,inName,l,cfg)
D=cfg.transformer.dModel; H=cfg.transformer.numHeads; F=cfg.transformer.ffn;
a=sprintf('attn%d',l); add1=sprintf('add_attn%d',l); n1=sprintf('norm_attn%d',l);
f1=sprintf('ff1_%d',l); g=sprintf('gelu%d',l); d=sprintf('drop%d',l); f2=sprintf('ff2_%d',l);
add2=sprintf('add_ff%d',l); n2=sprintf('norm_ff%d',l);
lg=addLayers(lg,selfAttentionLayer(H,D,DropoutProbability=cfg.transformer.dropout,Name=a));
lg=addLayers(lg,additionLayer(2,Name=add1));
lg=addLayers(lg,layerNormalizationLayer(Name=n1));
lg=addLayers(lg,[fullyConnectedLayer(F,Name=f1); geluLayer(Name=g); dropoutLayer(cfg.transformer.dropout,Name=d); fullyConnectedLayer(D,Name=f2)]);
lg=addLayers(lg,additionLayer(2,Name=add2));
lg=addLayers(lg,layerNormalizationLayer(Name=n2));
lg=connectLayers(lg,inName,a);
lg=connectLayers(lg,a,string(add1)+"/in1"); lg=connectLayers(lg,inName,string(add1)+"/in2");
lg=connectLayers(lg,add1,n1); lg=connectLayers(lg,n1,f1);
lg=connectLayers(lg,f2,string(add2)+"/in1"); lg=connectLayers(lg,n1,string(add2)+"/in2");
lg=connectLayers(lg,add2,n2); outName=string(n2);
end
