function cfg = cics_config(mode)
%CICS_CONFIG Central configuration for CICS2026 benchmark.
if nargin<1, mode="demo"; end
mode=string(mode);

cfg.root = fileparts(mfilename('fullpath'));
cfg.mode = mode;
cfg.seed = 260818;
cfg.featureNames = ["numSV","hDOP","vDOP","hAcc","vAcc","gSpeed", ...
    "CNO_mean","CNO_std","CNO_gap","low_elev_ratio","PR_RMS","Fault_SVID_count"];
cfg.priorWeights = single([1.0 1.5 1.5 2.0 2.0 1.0 1.0 1.5 1.5 2.0 1.5 1.5]);
cfg.window = 30;
cfg.threshold = 0.5;
cfg.hardFaultThresholdM = 3.0;

% Prior Transformer
cfg.transformer.dModel = 24;
cfg.transformer.numHeads = 4;
cfg.transformer.ffn = 64;
cfg.transformer.numLayers = 2;
cfg.transformer.dropout = 0.10;

% Temporal R-GAT
cfg.rgat.hidden = 24;
cfg.rgat.numHeads = 4;
cfg.rgat.numLayers = 2;
cfg.rgat.maxLag = 5;      % 0..5 past steps jointly considered
cfg.rgat.timeDim = 6;     % sinusoidal lag encoding dimension
cfg.rgat.useTimeEncoding = true;

% EDL
cfg.edl.betaWeak = 1.0;
cfg.edl.annealEpochs = 10;
cfg.edl.klHardWeight = 1.0;
cfg.edl.klWeakWeight = 1.0;

% Training
cfg.train.learnRate = 1e-3;
cfg.train.miniBatchSize = 32;
cfg.train.gradDecay = 0.9;
cfg.train.sqGradDecay = 0.999;
cfg.train.gradientClip = 5.0;

if mode=="demo"
    cfg.train.epochs = 2;
    cfg.demoMaxTrainWindows = 512;
    cfg.demoMaxTestWindows = 300;
    cfg.rgat.numHeads = 2;
    cfg.rgat.numLayers = 1;
    cfg.rgat.maxLag = 2;
    cfg.runAblations = false;
    cfg.runForecast = false;
    cfg.bootstrapSamples = 300;
    cfg.dataDir = fullfile(cfg.root,'data','demo');
    cfg.outputDir = fullfile(cfg.root,'outputs','DEMO_SMOKE_TEST_ONLY');
else
    cfg.train.epochs = 50;
    cfg.runAblations = true;
    cfg.runForecast = true;
    cfg.forecastHorizons = [1 5 10];
    cfg.bootstrapSamples = 2000;
    cfg.dataDir = fullfile(cfg.root,'data','real');
    stamp=datestr(now,'yyyymmdd_HHMMSS');
    cfg.outputDir = fullfile(cfg.root,'outputs',['REAL_' stamp]);
end

cfg.files.medium = fullfile(cfg.dataDir,'medium.csv');
cfg.files.harsh  = fullfile(cfg.dataDir,'harsh.csv');
cfg.files.deep   = fullfile(cfg.dataDir,'deep.csv');

% Baseline reproduction gate from prior presentation.
cfg.reproduction.targetF1 = 0.950;
cfg.reproduction.tolerance = 0.020;

cfg.modelList = [ ...
    "Transformer", ...
    "TransEDL-Hard", ...
    "TransEDL-Soft", ...
    "SoftLabel", ...
    "Transformer-DualEDL", ...
    "R-GAT-DualEDL", ...
    "R-GAT+Transformer-DualEDL", ...
    "TemporalR-GAT-DualEDL"];
if cfg.runAblations
    cfg.modelList=[cfg.modelList, ...
        "TemporalR-GAT-NoTimeEncoding", ...
        "TemporalR-GAT-NoRelationType", ...
        "TemporalR-GAT-1Head", ...
        "TemporalR-GAT-1Layer"];
end
end
