function L=dirichlet_kl_uniform(alpha)
%DIRICHLET_KL_UNIFORM Mean KL[Dir(alpha)||Dir(1)] over batch.
K=size(alpha,1); S=sum(alpha,1);
term1=gammaln(S)-sum(gammaln(alpha),1)-gammaln(single(K));
term2=sum((alpha-1).*(psi(alpha)-psi(S)),1);
L=mean(term1+term2,'all');
end
