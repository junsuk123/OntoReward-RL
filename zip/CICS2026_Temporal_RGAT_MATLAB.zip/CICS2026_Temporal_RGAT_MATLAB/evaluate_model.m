function R = evaluate_model(model,X,Yh,Ys,cfg)
%EVALUATE_MODEL Inference, metrics, predictions.
N=size(X,3); bs=max(1,cfg.train.miniBatchSize*2);
p=zeros(1,N,'single'); u=nan(1,N,'single');
for start=1:bs:N
    idx=start:min(start+bs-1,N);
    Xb=permute(X(:,:,idx),[1 3 2]); dlX=make_dl_batch(Xb);
    raw=predict(model.net,dlX); raw=gather(extractdata(raw));
    [pb,ub]=edl_decode(single(raw),model.lossMode);
    p(idx)=single(pb); u(idx)=single(ub);
end
M=compute_metrics(Yh,p,cfg.threshold);
pred=p>=cfg.threshold; correct=(pred(:)==logical(Yh(:)));
if any(isfinite(u))
    M.MeanUncertainty=mean(double(u(isfinite(u))));
    M.MeanUncertaintyCorrect=mean(double(u(correct' & isfinite(u))),'omitnan');
    M.MeanUncertaintyIncorrect=mean(double(u((~correct)' & isfinite(u))),'omitnan');
else
    M.MeanUncertainty=NaN; M.MeanUncertaintyCorrect=NaN; M.MeanUncertaintyIncorrect=NaN;
end
R=struct('name',model.name,'pFault',p,'uncertainty',u,'metrics',M, ...
    'Yhard',Yh,'Ysoft',Ys);
end
