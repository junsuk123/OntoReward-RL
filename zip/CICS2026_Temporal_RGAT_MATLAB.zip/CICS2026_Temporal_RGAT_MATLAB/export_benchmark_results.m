function export_benchmark_results(results,boot,mc,baseGate,metaTest,forecastTable,mu,sigma,cfg)
%EXPORT_BENCHMARK_RESULTS Write all metrics, predictions, statistics, manifest.
keys=fieldnames(results); rows={};
for i=1:numel(keys)
    R=results.(keys{i}); M=R.metrics;
    rows(end+1,:)={char(R.name),M.TP,M.TN,M.FP,M.FN,M.Accuracy,M.Precision,M.Recall,M.Specificity, ...
        M.F1,M.AUROC,M.AUPRC,M.Brier,M.NLL,M.ECE,M.MeanUncertainty,M.MeanUncertaintyCorrect,M.MeanUncertaintyIncorrect}; %#ok<AGROW>
    P=metaTest; P.hard_label=R.Yhard(:); P.soft_fault_prob=R.Ysoft(:); P.p_fault=R.pFault(:); P.uncertainty=R.uncertainty(:);
    writetable(P,fullfile(cfg.outputDir,['predictions_' keys{i} '.csv']));
end
metrics=cell2table(rows,'VariableNames',{'Model','TP','TN','FP','FN','Accuracy','Precision','Recall','Specificity','F1','AUROC','AUPRC','Brier','NLL','ECE','MeanUncertainty','MeanUncertaintyCorrect','MeanUncertaintyIncorrect'});
writetable(metrics,fullfile(cfg.outputDir,'metrics.csv'));
% Compare reproduced metrics with values exactly as displayed in the prior presentation.
priorFile=fullfile(cfg.root,'prior_reported_metrics.csv');
if isfile(priorFile)
    P=readtable(priorFile);
    C=outerjoin(P,metrics(:,{'Model','Precision','Recall','F1'}),'Keys','Model','MergeKeys',true,'Type','left');
    C.DeltaPrecision=C.Precision-C.ReportedPrecision;
    C.DeltaRecall=C.Recall-C.ReportedRecall;
    C.DeltaF1=C.F1-C.ReportedF1;
    writetable(C,fullfile(cfg.outputDir,'prior_reported_comparison.csv'));
end
writetable(struct2table(boot),fullfile(cfg.outputDir,'paired_bootstrap_vs_prior.csv'));
writetable(struct2table(mc),fullfile(cfg.outputDir,'mcnemar_vs_prior.csv'));
if ~isempty(forecastTable), writetable(forecastTable,fullfile(cfg.outputDir,'forecast_metrics.csv')); end
manifest=struct(); manifest.mode=char(cfg.mode); manifest.created=datestr(now,31); manifest.seed=cfg.seed;
manifest.trainScenarios={'medium','harsh'}; manifest.testScenario='deep'; manifest.window=cfg.window;
manifest.featureNames=cellstr(cfg.featureNames); manifest.normalizationMean=double(mu); manifest.normalizationStd=double(sigma);
manifest.priorF1Target=cfg.reproduction.targetF1; manifest.priorTolerance=cfg.reproduction.tolerance;
manifest.baselineReproductionPass=logical(baseGate); manifest.note='Demo metrics are smoke-test only; real claims require strict processed UrbanNav data.';
fid=fopen(fullfile(cfg.outputDir,'run_manifest.json'),'w'); fprintf(fid,'%s',jsonencode(manifest,PrettyPrint=true)); fclose(fid);
end
