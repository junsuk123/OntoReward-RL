function dlX=make_dl_batch(Xb)
%MAKE_DL_BATCH Create CBT dlarray and use GPU only when available.
Xb=single(Xb);
useGPU=false;
if exist('gpuDeviceCount','file')==2
    try
        useGPU=gpuDeviceCount("available")>0;
    catch
        try, useGPU=gpuDeviceCount>0; catch, useGPU=false; end
    end
end
if useGPU, Xb=gpuArray(Xb); end
dlX=dlarray(Xb,'CBT');
end
