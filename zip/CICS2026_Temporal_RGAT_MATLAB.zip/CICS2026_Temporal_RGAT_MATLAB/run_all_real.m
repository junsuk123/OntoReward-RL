function run_all_real()
%RUN_ALL_REAL Strict experiment on real processed UrbanNav-HK tables.
root=fileparts(mfilename('fullpath'));
addpath(root); addpath(fullfile(root,'tests'));
check_environment();
cfg=cics_config("real");
missing=string.empty;
for s=["medium","harsh","deep"]
    if ~isfile(cfg.files.(char(s))), missing(end+1)=string(cfg.files.(char(s))); end %#ok<AGROW>
end
if ~isempty(missing)
    fprintf('\nMissing strict processed files:\n'); disp(missing');
    fprintf('Use find_and_import_prior_data(<searchRoot>) or place the files manually.\n');
    fprintf('For raw UrbanNav download links run: open_urbannav_dataset\n');
    error('Strict real-data benchmark cannot start without all three processed tables.');
end
run_benchmark("real");
end
