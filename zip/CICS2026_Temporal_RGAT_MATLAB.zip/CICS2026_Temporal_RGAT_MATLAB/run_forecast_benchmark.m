function T = run_forecast_benchmark(D,cfg)
%RUN_FORECAST_BENCHMARK Compare future fault prediction at multiple horizons.
rows={};
for h=cfg.forecastHorizons
    fprintf('\n=== Forecast horizon k=%d ===\n',h);
    Dbase=D; for s=["medium","harsh","deep"], Dbase.(char(s)).X=D.(char(s)).X.*cfg.priorWeights; end
    [XB,yhb,ysb]=concat_windows(Dbase.medium,Dbase.harsh,cfg,h);
    [XBte,yht,yst]=make_windows(Dbase.deep,cfg,h);
    [XP,yhp,ysp]=concat_windows(D.medium,D.harsh,cfg,h);
    [XPte,yht2,yst2]=make_windows(D.deep,cfg,h);
    assert(isequal(yhb,yhp) && isequal(ysb,ysp));
    assert(isequal(yht,yht2) && isequal(yst,yst2));
    names=["Transformer-DualEDL","TemporalR-GAT-DualEDL"];
    for name=names
        model=build_model(name,cfg);
        if name=="Transformer-DualEDL", Xtr=XB; Xte=XBte; else, Xtr=XP; Xte=XPte; end
        [model,~]=train_model(model,Xtr,yhb,ysb,cfg);
        R=evaluate_model(model,Xte,yht,yst,cfg); M=R.metrics;
        rows(end+1,:)={h,char(name),M.Precision,M.Recall,M.F1,M.AUROC,M.AUPRC,M.Brier}; %#ok<AGROW>
    end
end
T=cell2table(rows,'VariableNames',{'Horizon','Model','Precision','Recall','F1','AUROC','AUPRC','Brier'});
end
