function [model,history] = train_model(model,X,Yh,Ys,cfg)
%TRAIN_MODEL Custom Adam training loop.
net=model.net; N=size(X,3); bs=cfg.train.miniBatchSize;
avg=[]; avgSq=[]; iter=0;
histEpoch=zeros(cfg.train.epochs,1); histLoss=zeros(cfg.train.epochs,1);
fprintf('\nTraining %-34s | %d windows | %d epochs\n',model.name,N,cfg.train.epochs);
for epoch=1:cfg.train.epochs
    order=randperm(N); epochLoss=0; nBatch=0;
    for start=1:bs:N
        iter=iter+1; idx=order(start:min(start+bs-1,N));
        Xb=permute(X(:,:,idx),[1 3 2]); % C x B x T
        dlX=make_dl_batch(Xb);
        yh=single(Yh(idx)); ys=single(Ys(idx));
        [loss,grads,state]=dlfeval(@model_gradients,net,dlX,yh,ys,model.lossMode,cfg,epoch);
        net.State=state;
        grads=dlupdate(@(g)clip_gradient(g,cfg.train.gradientClip),grads);
        [net,avg,avgSq]=adamupdate(net,grads,avg,avgSq,iter,cfg.train.learnRate, ...
            cfg.train.gradDecay,cfg.train.sqGradDecay);
        epochLoss=epochLoss+double(gather(extractdata(loss))); nBatch=nBatch+1;
    end
    histEpoch(epoch)=epoch; histLoss(epoch)=epochLoss/max(1,nBatch);
    fprintf('  epoch %3d/%3d | loss %.5f\n',epoch,cfg.train.epochs,histLoss(epoch));
end
model.net=net; history=table(histEpoch,histLoss,'VariableNames',{'Epoch','Loss'});
end
function g=clip_gradient(g,thr)
if isempty(g), return; end
g=max(min(g,thr),-thr);
end
